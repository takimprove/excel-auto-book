import pandas as pd

df = pd.read_excel("商品一覧_9月.xlsx")
df.to_excel("コピー.xlsx", index=False)
print("保存しました")
