@echo off
cd /d %~dp0
python matome.py
pause
