import pandas as pd

df = pd.read_excel("商品一覧_9月.xlsx")
print(df)
print(len(df), "行あります")
print(df["商品名"])
