@echo off
cd /d %~dp0
python mikurabe.py
pause
