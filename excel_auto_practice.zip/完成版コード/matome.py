from pathlib import Path
import pandas as pd

folder = Path("売上")
frames = []
for f in sorted(folder.glob("*.xlsx")):
    df = pd.read_excel(f)
    df["元ファイル"] = f.name
    frames.append(df)

if not frames:
    raise SystemExit("「売上」フォルダにExcelファイルが見つかりません。置き場所を確かめてください。")

all_df = pd.concat(frames, ignore_index=True)
all_df["日付"] = pd.to_datetime(all_df["日付"]).dt.date
all_df.to_excel("まとめ.xlsx", index=False)
print(len(frames), "個のファイルから", len(all_df), "行をまとめました")
