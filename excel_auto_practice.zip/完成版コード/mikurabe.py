import pandas as pd

old = pd.read_excel("前月.xlsx", dtype=str).fillna("")
new = pd.read_excel("今月.xlsx", dtype=str).fillna("")
key = "商品コード"

added = new[~new[key].isin(old[key])]
deleted = old[~old[key].isin(new[key])]

both = old.merge(new, on=key, suffixes=("_前", "_後"))
cols = [c for c in old.columns if c != key and c in new.columns]
rows = []
for _, r in both.iterrows():
    for c in cols:
        if r[c + "_前"] != r[c + "_後"]:
            rows.append({key: r[key], "変わった列": c,
                         "前の値": r[c + "_前"], "新しい値": r[c + "_後"]})
changed = pd.DataFrame(rows, columns=[key, "変わった列", "前の値", "新しい値"])

with pd.ExcelWriter("見比べ結果.xlsx") as w:
    added.to_excel(w, sheet_name="追加", index=False)
    deleted.to_excel(w, sheet_name="削除", index=False)
    changed.to_excel(w, sheet_name="変更", index=False)

print("追加", len(added), "件 / 削除", len(deleted), "件 / 変更", len(changed), "か所")
